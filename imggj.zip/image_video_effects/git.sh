git add .
git commit -m "push fix"
git push
